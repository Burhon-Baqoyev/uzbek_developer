from django.shortcuts import render, redirect
from .models import Post
from .form import PostForm

# Create your views here.
def index(request):
    post = Post.objects.all()
    context = {'content':post}
    return render(request,'index.html', context)

def add(request):

    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    form = PostForm
    context = {'form':form}

    return render(request,'add.html',context)